const login = require("facebook-chat-api");
const fs = require("fs");

const credentials = {
  email: "baonamt991@gmail.com",
  password: "Bnam30042009@"
};

login(credentials, (err, api) => {
  if (err) {
    console.error("❌ Lỗi đăng nhập:", err);
    return;
  }

  fs.writeFileSync("appstate.json", JSON.stringify(api.getAppState(), null, 2));
  console.log("✅ Appstate đã được lưu vào file appstate.json");
});